-- ============================================
-- Database PPDB SMK N 1 LIWA
-- Import via phpMyAdmin di hosting Anda
-- ============================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- --------------------------------------------
-- Tabel users (pendaftar yang punya akun login)
-- --------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nama` VARCHAR(150) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `no_hp` VARCHAR(20) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------
-- Tabel admin
-- --------------------------------------------
CREATE TABLE IF NOT EXISTS `admin` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `nama_lengkap` VARCHAR(150) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `level` ENUM('admin','super_admin') DEFAULT 'admin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Admin default
-- Email: admin@smkn1liwa.sch.id
-- Password: admin123
INSERT INTO `admin` (`username`,`password`,`nama_lengkap`,`email`,`level`) VALUES
('admin','$2y$12$ioBJf1QtfkfU5smRgcX06O8hxsF1cSYdUzEfCWeTXNeKxWqFdC5jK','Administrator','admin@smkn1liwa.sch.id','super_admin');

-- --------------------------------------------
-- Tabel pendaftar (data pendaftaran PPDB)
-- --------------------------------------------
CREATE TABLE IF NOT EXISTS `pendaftar` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) DEFAULT NULL,
  `no_pendaftaran` VARCHAR(30) NOT NULL UNIQUE,
  `nama_lengkap` VARCHAR(150) NOT NULL,
  `nisn` VARCHAR(20) DEFAULT NULL,
  `jenis_kelamin` ENUM('L','P') DEFAULT 'L',
  `tempat_lahir` VARCHAR(100) DEFAULT NULL,
  `tanggal_lahir` DATE DEFAULT NULL,
  `agama` VARCHAR(30) DEFAULT NULL,
  `alamat` TEXT,
  `no_hp` VARCHAR(20) DEFAULT NULL,
  `asal_sekolah` VARCHAR(150) DEFAULT NULL,
  `tahun_lulus` YEAR DEFAULT NULL,
  `jurusan_pilihan` VARCHAR(100) DEFAULT NULL,
  `nama_ayah` VARCHAR(150) DEFAULT NULL,
  `nama_ibu` VARCHAR(150) DEFAULT NULL,
  `pekerjaan_ortu` VARCHAR(100) DEFAULT NULL,
  `no_hp_ortu` VARCHAR(20) DEFAULT NULL,
  `foto` VARCHAR(255) DEFAULT NULL,
  `ijazah` VARCHAR(255) DEFAULT NULL,
  `kk` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('pending','verifikasi','diterima','ditolak') DEFAULT 'pending',
  `tanggal_daftar` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------
-- Tabel pengaturan
-- --------------------------------------------
CREATE TABLE IF NOT EXISTS `pengaturan` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nama_sekolah` VARCHAR(150) DEFAULT 'SMK N 1 LIWA',
  `alamat_sekolah` TEXT,
  `telp_sekolah` VARCHAR(20) DEFAULT NULL,
  `email_sekolah` VARCHAR(150) DEFAULT NULL,
  `tahun_ajaran` VARCHAR(20) DEFAULT '2026/2027',
  `kepala_sekolah` VARCHAR(150) DEFAULT NULL,
  `nip_kepsek` VARCHAR(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `pengaturan` (`id`,`nama_sekolah`,`alamat_sekolah`,`telp_sekolah`,`email_sekolah`,`tahun_ajaran`,`kepala_sekolah`,`nip_kepsek`) VALUES
(1,'SMK N 1 LIWA','Jl. Pendidikan No. 1, Liwa, Lampung Barat','0728-12345','info@smkn1liwa.sch.id','2026/2027','Drs. Kepala Sekolah','19700101 199001 1 001');
