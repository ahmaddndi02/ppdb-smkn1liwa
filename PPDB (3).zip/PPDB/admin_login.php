<?php
// Redirect ke halaman login utama dengan tab Admin aktif
header("Location: login.php");
exit;
?>
