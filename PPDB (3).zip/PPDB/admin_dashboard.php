<?php
require_once 'config/database.php';

if (!isset($_SESSION['admin_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: login.php");
    exit;
}

// Aksi ubah status
if (isset($_GET['ubah']) && isset($_GET['status'])) {
    $id = (int)$_GET['ubah'];
    $status = $_GET['status'];
    if (in_array($status, ['pending','verifikasi','diterima','ditolak'])) {
        $stmt = $pdo->prepare("UPDATE pendaftar SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
    }
    header("Location: admin_dashboard.php");
    exit;
}

// Aksi hapus
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $pdo->prepare("DELETE FROM pendaftar WHERE id = ?")->execute([$id]);
    header("Location: admin_dashboard.php");
    exit;
}

$pendaftar = $pdo->query("SELECT * FROM pendaftar ORDER BY tanggal_daftar DESC")->fetchAll();
$total = count($pendaftar);
$diterima = count(array_filter($pendaftar, fn($p)=>$p['status']=='diterima'));
$pending  = count(array_filter($pendaftar, fn($p)=>$p['status']=='pending'));
$ditolak  = count(array_filter($pendaftar, fn($p)=>$p['status']=='ditolak'));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - SMK N 1 LIWA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: linear-gradient(135deg, #e3f2fd, #ffffff); font-family: 'Segoe UI', sans-serif; min-height:100vh; }
        .navbar { background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.05); padding: 12px 0; }
        .navbar-brand { display:flex; align-items:center; gap:10px; font-weight:bold; font-size:20px; color:#0d47a1; text-decoration:none; }
        .navbar-brand img { height: 40px; }
        .stat-card { background: white; border-radius: 20px; padding: 25px 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); text-align:center; transition:.3s; }
        .stat-card:hover{ transform: translateY(-4px); }
        .stat-icon { width:70px; height:70px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 12px; color:#fff; font-size:28px; }
        .stat-icon.blue   { background: linear-gradient(135deg,#0d47a1,#1976d2); }
        .stat-icon.yellow { background: linear-gradient(135deg,#f9a825,#fbc02d); }
        .stat-icon.green  { background: linear-gradient(135deg,#2e7d32,#43a047); }
        .stat-icon.red    { background: linear-gradient(135deg,#c62828,#e53935); }
        .stat-card h2 { color:#0d47a1; margin:0; font-weight:700; }
        .stat-card small { color:#666; font-weight:600; }
        .main-card { background: white; border-radius: 20px; padding: 25px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); margin-top: 20px; }
        .status-badge { padding:4px 12px; border-radius:50px; font-size:12px; font-weight:bold; }
        .status-pending{background:#fff3cd;color:#856404;}
        .status-verifikasi{background:#d1ecf1;color:#0c5460;}
        .status-diterima{background:#d4edda;color:#155724;}
        .status-ditolak{background:#f8d7da;color:#721c24;}
        .table-scroll { overflow-x:auto; -webkit-overflow-scrolling: touch; }
        .table-scroll table { min-width: 900px; margin-bottom:0; }
        .table-scroll::-webkit-scrollbar { height: 10px; }
        .table-scroll::-webkit-scrollbar-thumb { background:#90caf9; border-radius:10px; }
        .btn-action { border-radius:50px; padding:6px 16px; font-weight:600; }
        footer { background: white; border-radius: 10px; padding: 15px; text-align: center; margin-top: 30px; color:#555; }
        @media(max-width: 576px){
            .navbar-brand { font-size: 16px; }
            .navbar-actions { margin-top: 10px; width:100%; display:flex; gap:6px; }
            .navbar-actions .btn { flex:1; }
        }
    </style>
</head>
<body>
<nav class="navbar">
    <div class="container flex-wrap">
        <a class="navbar-brand" href="admin_dashboard.php">
            <img src="assets/img/logo.jpg" onerror="this.src='https://placehold.co/40x40?text=SMK'">
            Admin Panel - SMK N 1 LIWA
        </a>
        <div class="navbar-actions d-flex align-items-center gap-2">
            <span class="text-muted d-none d-md-inline me-2">Halo, <?= htmlspecialchars($_SESSION['admin_nama'] ?? 'Admin') ?></span>
            <a href="export_excel.php" class="btn btn-success btn-sm btn-action"><i class="fas fa-file-excel me-1"></i> Export Excel</a>
            <a href="logout.php" class="btn btn-danger btn-sm btn-action"><i class="fas fa-sign-out-alt me-1"></i> Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="row g-3">
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-icon blue"><i class="fas fa-users"></i></div>
                <h2><?= $total ?></h2>
                <small>Total Pendaftar</small>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-icon yellow"><i class="fas fa-clock"></i></div>
                <h2><?= $pending ?></h2>
                <small>Pending</small>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-icon green"><i class="fas fa-check"></i></div>
                <h2><?= $diterima ?></h2>
                <small>Diterima</small>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-icon red"><i class="fas fa-xmark"></i></div>
                <h2><?= $ditolak ?></h2>
                <small>Ditolak</small>
            </div>
        </div>
    </div>

    <div class="main-card">
        <h4 class="mb-3" style="color:#0d47a1;"><i class="fas fa-list me-2"></i> Daftar Pendaftar</h4>
        <div class="table-scroll">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>No</th><th>No. Pendaftaran</th><th>Nama</th><th>Asal Sekolah</th>
                    <th>Tanggal</th><th>Status</th><th class="text-end">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($pendaftar)): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">Belum ada pendaftar.</td></tr>
            <?php else: $no=1; foreach($pendaftar as $p): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($p['no_pendaftaran']) ?></td>
                    <td><?= htmlspecialchars($p['nama_lengkap']) ?></td>
                    <td><?= htmlspecialchars($p['asal_sekolah'] ?? '-') ?></td>
                    <td><?= date('d-m-Y', strtotime($p['tanggal_daftar'])) ?></td>
                    <td><span class="status-badge status-<?= $p['status'] ?>"><?= strtoupper($p['status']) ?></span></td>
                    <td class="text-end">
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown"><i class="fas fa-pen me-1"></i> Status</button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="?ubah=<?= $p['id'] ?>&status=pending"><i class="fas fa-clock text-warning me-2"></i>Pending</a></li>
                                <li><a class="dropdown-item" href="?ubah=<?= $p['id'] ?>&status=verifikasi"><i class="fas fa-spinner text-info me-2"></i>Verifikasi</a></li>
                                <li><a class="dropdown-item" href="?ubah=<?= $p['id'] ?>&status=diterima"><i class="fas fa-check text-success me-2"></i>Diterima</a></li>
                                <li><a class="dropdown-item" href="?ubah=<?= $p['id'] ?>&status=ditolak"><i class="fas fa-xmark text-danger me-2"></i>Ditolak</a></li>
                            </ul>
                            <a href="?hapus=<?= $p['id'] ?>" class="btn btn-outline-danger" onclick="return confirm('Hapus pendaftar ini?')"><i class="fas fa-trash"></i></a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
        </div>
    </div>

    <footer>&copy; <?= date('Y') ?> SMK N 1 LIWA - Admin Panel</footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
