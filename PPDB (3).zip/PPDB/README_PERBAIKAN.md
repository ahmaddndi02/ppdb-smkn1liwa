# PPDB SMK N 1 LIWA - Perbaikan

## Apa yang diperbaiki (desain TIDAK diubah)
1. **Database** — file `database.sql` di-import via phpMyAdmin.
2. **Admin login** — dibuat `admin_dashboard.php` baru, `admin_login.php` redirect ke `login.php` (pilih tab **Admin**).
3. **Logout di laptop** — tombol Logout sekarang **juga muncul di sidebar** portal (berwarna merah), jadi selalu terlihat baik di laptop maupun HP.
4. **Bug session** — `$_SESSION['user_nama']` → `$_SESSION['nama']` (sesuai login.php).

## Login Admin Default
- URL: `login.php` → pilih tab **Admin**
- Email: `admin@smkn1liwa.sch.id`
- Password: `admin123`

Jika login admin gagal, buka `reset_admin.php` di browser sekali, lalu **hapus file itu** demi keamanan.

## Cara Hosting Ulang
1. Upload semua file ke hosting.
2. Buat database baru di hosting, lalu import `database.sql` via phpMyAdmin.
3. Edit `config/database.php`: sesuaikan `$host`, `$dbname`, `$username`, `$password`.
4. Buka `login.php` → tab Admin → masuk dengan kredensial di atas.

## Penting
- Hapus `reset_admin.php` setelah dipakai.
- Ganti password admin setelah login pertama.
