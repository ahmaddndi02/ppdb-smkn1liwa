<?php
session_start();
require_once 'config/database.php';

// Cek login admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Cek apakah admin super
if ($_SESSION['admin_level'] != 'super_admin') {
    header("Location: admin_dashboard.php");
    exit;
}

$error = '';
$success = '';

// Ambil daftar admin
$stmt = $pdo->query("SELECT * FROM admin ORDER BY created_at DESC");
$admins = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $nama_lengkap = trim($_POST['nama_lengkap']);
    $email = trim($_POST['email']);
    $level = $_POST['level'];

    // Validasi
    if (empty($username) || empty($password) || empty($nama_lengkap)) {
        $error = "Username, password, dan nama lengkap wajib diisi!";
    } elseif ($password !== $confirm_password) {
        $error = "Password dan konfirmasi password tidak sama!";
    } elseif (strlen($password) < 4) {
        $error = "Password minimal 4 karakter!";
    } else {
        // Cek username sudah ada
        $stmt = $pdo->prepare("SELECT id FROM admin WHERE username = ?");
        $stmt->execute([$username]);
        
        if ($stmt->rowCount() > 0) {
            $error = "Username sudah terdaftar!";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO admin (username, password, nama_lengkap, email, level) VALUES (?, ?, ?, ?, ?)");
            
            if ($stmt->execute([$username, $hashed_password, $nama_lengkap, $email, $level])) {
                $success = "Admin baru berhasil ditambahkan!";
                // Refresh daftar admin
                $stmt = $pdo->query("SELECT * FROM admin ORDER BY created_at DESC");
                $admins = $stmt->fetchAll();
                $_POST = [];
            } else {
                $error = "Gagal menambahkan admin, coba lagi.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Admin - SMK N 1 LIWA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        .sidebar { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .sidebar a { text-decoration: none; color: #333; display: block; padding: 10px; border-radius: 8px; margin-bottom: 5px; }
        .sidebar a:hover, .sidebar a.active { background: #0d47a1; color: white; }
        .navbar { background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.05); padding: 12px 0; }
        .card-custom { background: white; border-radius: 15px; padding: 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); margin-bottom: 20px; }
        .btn-simpan { background: linear-gradient(135deg, #0d47a1, #1976d2); color: white; padding: 10px 30px; border-radius: 50px; border: none; }
        .btn-simpan:hover { transform: translateY(-2px); }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary" href="admin_dashboard.php">
            <i class="fas fa-school"></i> Admin PPDB
        </a>
        <div>
            <span class="text-muted me-3">Halo, <?= htmlspecialchars($_SESSION['admin_nama']) ?></span>
            <a href="admin_logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="sidebar">
                <h5 class="mb-3">Menu Admin</h5>
                <ul class="list-unstyled">
                    <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
                    <li><a href="admin_pendaftar.php"><i class="fas fa-users me-2"></i> Data Pendaftar</a></li>
                    <li><a href="admin_tambah.php" class="active"><i class="fas fa-user-plus me-2"></i> Tambah Admin</a></li>
                    <li><a href="admin_pengaturan.php"><i class="fas fa-cog me-2"></i> Pengaturan</a></li>
                    <li><a href="admin_logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                </ul>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <!-- Form Tambah Admin -->
            <div class="card-custom">
                <h4 class="mb-4" style="color: #0d47a1;"><i class="fas fa-user-plus me-2"></i> Tambah Admin Baru</h4>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success"><?= $success ?></div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Username <span class="text-danger">*</span></label>
                            <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Level</label>
                            <select name="level" class="form-control">
                                <option value="admin">Admin</option>
                                <option value="super_admin">Super Admin</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Password <span class="text-danger">*</span></label>
                            <input type="password" name="password" class="form-control" required>
                            <small class="text-muted">Minimal 4 karakter</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Konfirmasi Password <span class="text-danger">*</span></label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                            <input type="text" name="nama_lengkap" class="form-control" value="<?= htmlspecialchars($_POST['nama_lengkap'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="text-center mt-3">
                        <button type="submit" class="btn-simpan"><i class="fas fa-save me-2"></i> Simpan Admin</button>
                        <a href="admin_dashboard.php" class="btn btn-secondary ms-2">Batal</a>
                    </div>
                </form>
            </div>
            
            <!-- Daftar Admin -->
            <div class="card-custom">
                <h4 class="mb-3" style="color: #0d47a1;"><i class="fas fa-list me-2"></i> Daftar Admin</h4>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Username</th>
                                <th>Nama Lengkap</th>
                                <th>Email</th>
                                <th>Level</th>
                                <th>Tanggal Dibuat</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; foreach($admins as $a): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($a['username']) ?></td>
                                <td><?= htmlspecialchars($a['nama_lengkap']) ?></td>
                                <td><?= htmlspecialchars($a['email'] ?? '-') ?></td>
                                <td>
                                    <?php if($a['level'] == 'super_admin'): ?>
                                        <span class="badge bg-primary">Super Admin</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Admin</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= date('d-m-Y H:i', strtotime($a['created_at'])) ?></td>
                                <td>
                                    <?php if($a['id'] != $_SESSION['admin_id']): ?>
                                        <a href="admin_hapus_admin.php?id=<?= $a['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus admin ini?')">Hapus</a>
                                    <?php else: ?>
                                        <span class="text-muted">(Anda)</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>