<?php
session_start();
require_once 'config/database.php';

// Cek login admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Ambil statistik
$stmt = $pdo->query("SELECT COUNT(*) as total FROM pendaftar");
$total_pendaftar = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM pendaftar WHERE status = 'pending'");
$pending = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM pendaftar WHERE status = 'verifikasi'");
$verifikasi = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM pendaftar WHERE status = 'diterima'");
$diterima = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM pendaftar WHERE status = 'ditolak'");
$ditolak = $stmt->fetch()['total'];

// Ambil 5 pendaftar terbaru
$stmt = $pdo->query("SELECT * FROM pendaftar ORDER BY tanggal_daftar DESC LIMIT 5");
$recent = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SMK N 1 LIWA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        .sidebar { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); position: sticky; top: 20px; }
        .sidebar ul { list-style: none; padding: 0; }
        .sidebar li { margin-bottom: 10px; }
        .sidebar a { text-decoration: none; color: #333; display: flex; align-items: center; gap: 12px; padding: 10px; border-radius: 8px; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background: #0d47a1; color: white; }
        .stat-card { background: white; border-radius: 15px; padding: 20px; text-align: center; box-shadow: 0 2px 8px rgba(0,0,0,0.05); transition: 0.3s; }
        .stat-card:hover { transform: translateY(-5px); }
        .stat-number { font-size: 32px; font-weight: bold; color: #0d47a1; }
        .stat-label { color: #6c757d; font-size: 14px; }
        .navbar { background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.05); padding: 12px 0; }
        .navbar-brand { display: flex; align-items: center; gap: 12px; font-weight: bold; font-size: 22px; color: #0d47a1; text-decoration: none; }
        .navbar-brand img { height: 40px; width: auto; }
        .btn-sm-custom { padding: 3px 10px; font-size: 12px; border-radius: 20px; }
        .chart-container { background: white; border-radius: 15px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="container">
        <a class="navbar-brand" href="admin_dashboard.php">
            <img src="assets/img/logo.jpg" alt="Logo">
            Admin PPDB
        </a>
        <div>
            <span class="text-muted me-3">Halo, <?= htmlspecialchars($_SESSION['admin_nama']) ?></span>
            <a href="admin_logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="sidebar">
                <h5 class="mb-3">Menu Admin</h5>
                <ul>
                    <li><a href="admin_dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="admin_pendaftar.php"><i class="fas fa-users"></i> Data Pendaftar</a></li>
                    <?php if ($_SESSION['admin_level'] == 'super_admin'): ?>
                        <li><a href="admin_tambah.php"><i class="fas fa-user-plus"></i> Tambah Admin</a></li>
                    <?php endif; ?>
                    <li><a href="admin_pengaturan.php"><i class="fas fa-cog"></i> Pengaturan</a></li>
                    <li><a href="admin_logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <!-- Statistik Card -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-number"><?= $total_pendaftar ?></div>
                        <div class="stat-label">Total Pendaftar</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-number" style="color: #ffc107;"><?= $pending ?></div>
                        <div class="stat-label">Menunggu Verifikasi</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-number" style="color: #17a2b8;"><?= $verifikasi ?></div>
                        <div class="stat-label">Sedang Diverifikasi</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-number" style="color: #28a745;"><?= $diterima ?></div>
                        <div class="stat-label">Diterima</div>
                    </div>
                </div>
            </div>

            <!-- Grafik Statistik -->
            <div class="chart-container mb-4">
                <h5 class="mb-3"><i class="fas fa-chart-pie me-2"></i> Statistik Status Pendaftaran</h5>
                <canvas id="statusChart" style="max-height: 300px; width: 100%;"></canvas>
            </div>

            <!-- Pendaftar Terbaru -->
            <div class="card">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-clock me-2"></i> Pendaftar Terbaru</h5>
                    <a href="export_excel.php" class="btn btn-success btn-sm">
                        <i class="fas fa-file-excel me-1"></i> Export ke Excel
                    </a>
                </div>
                <div class="card-body p-0">
                    <table class="table table-bordered mb-0">
                        <thead class="table-light">
                            <tr><th>No Pendaftaran</th><th>Nama</th><th>Tgl Daftar</th><th>Status</th><th>Aksi</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach($recent as $r): ?>
                            <tr>
                                <td><?= $r['no_pendaftaran'] ?></td>
                                <td><?= htmlspecialchars($r['nama_lengkap']) ?></td>
                                <td><?= date('d-m-Y H:i', strtotime($r['tanggal_daftar'])) ?></td>
                                <td>
                                    <?php
                                    $badge = 'secondary';
                                    if($r['status'] == 'pending') $badge = 'warning';
                                    elseif($r['status'] == 'verifikasi') $badge = 'info';
                                    elseif($r['status'] == 'diterima') $badge = 'success';
                                    elseif($r['status'] == 'ditolak') $badge = 'danger';
                                    ?>
                                    <span class="badge bg-<?= $badge ?>"><?= strtoupper($r['status']) ?></span>
                                </td>
                                <td>
                                    <a href="admin_edit_pendaftar.php?id=<?= $r['id'] ?>" class="btn btn-primary btn-sm btn-sm-custom">Edit</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(count($recent) == 0): ?>
                            <td><td colspan="5" class="text-center">Belum ada data pendaftar</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Grafik Statistik
const ctx = document.getElementById('statusChart').getContext('2d');
new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: ['Pending (Menunggu)', 'Verifikasi (Proses)', 'Diterima', 'Ditolak'],
        datasets: [{
            data: [<?= $pending ?>, <?= $verifikasi ?>, <?= $diterima ?>, <?= $ditolak ?>],
            backgroundColor: ['#ffc107', '#17a2b8', '#28a745', '#dc3545'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: { position: 'bottom' },
            title: { display: true, text: 'Status Pendaftaran Siswa' }
        }
    }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>