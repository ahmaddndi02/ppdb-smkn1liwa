<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Fungsi kirim notifikasi email
function sendNotifikasi($to, $name, $status, $no_pendaftaran) {
    $status_text = '';
    if($status == 'diterima') $status_text = 'DITERIMA';
    elseif($status == 'ditolak') $status_text = 'DITOLAK';
    elseif($status == 'verifikasi') $status_text = 'SEDANG DIPROSES';
    else $status_text = 'MENUNGGU VERIFIKASI';
    
    $subject = "Notifikasi Pendaftaran PPDB - SMK N 1 LIWA";
    $message = "Yth. $name,\n\n";
    $message .= "Status pendaftaran Anda saat ini: $status_text\n\n";
    $message .= "Nomor Pendaftaran: $no_pendaftaran\n\n";
    $message .= "Silakan login ke portal PPDB untuk informasi lebih lanjut.\n\n";
    $message .= "Terima kasih,\nPanitia PPDB SMK N 1 LIWA";
    
    // Simpan ke file log
    $log = date('Y-m-d H:i:s') . " - To: $to - Status: $status_text\n";
    file_put_contents("email_log.txt", $log, FILE_APPEND);
    return true;
}

// Proses kirim notifikasi
if (isset($_GET['kirim_notif']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM pendaftar WHERE id = ?");
    $stmt->execute([$id]);
    $pendaftar_notif = $stmt->fetch();
    
    if ($pendaftar_notif) {
        sendNotifikasi($pendaftar_notif['email'], $pendaftar_notif['nama_lengkap'], $pendaftar_notif['status'], $pendaftar_notif['no_pendaftaran']);
        $notif_success = "Notifikasi berhasil dikirim ke " . $pendaftar_notif['email'];
    }
}

// Pagination
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Filter status
$status_filter = $_GET['status'] ?? '';
$where = "";
if ($status_filter) {
    $where = "WHERE status = '$status_filter'";
}

// Total data
$stmt = $pdo->query("SELECT COUNT(*) as total FROM pendaftar $where");
$total = $stmt->fetch()['total'];
$total_pages = ceil($total / $limit);

// Ambil data
$stmt = $pdo->prepare("SELECT * FROM pendaftar $where ORDER BY tanggal_daftar DESC LIMIT $limit OFFSET $offset");
$stmt->execute();
$pendaftar = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pendaftar - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        .sidebar { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .sidebar a { text-decoration: none; color: #333; display: block; padding: 10px; border-radius: 8px; margin-bottom: 5px; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background: #0d47a1; color: white; }
        .navbar { background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.05); padding: 12px 0; }
        .navbar-brand { display: flex; align-items: center; gap: 12px; font-weight: bold; font-size: 22px; color: #0d47a1; text-decoration: none; }
        .navbar-brand img { height: 40px; width: auto; }
        .btn-sm-custom { padding: 3px 10px; font-size: 12px; border-radius: 20px; }
        .btn-notif { background: #17a2b8; color: white; padding: 3px 10px; font-size: 12px; border-radius: 20px; border: none; }
        .btn-notif:hover { background: #138496; color: white; }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="container">
        <a class="navbar-brand" href="admin_dashboard.php">
            <img src="assets/img/logo.jpg" alt="Logo">
            Admin PPDB
        </a>
        <div>
            <span class="text-muted me-3">Halo, <?= htmlspecialchars($_SESSION['admin_nama']) ?></span>
            <a href="admin_logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="sidebar">
                <h5 class="mb-3">Menu Admin</h5>
                <ul class="list-unstyled">
                    <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
                    <li><a href="admin_pendaftar.php" class="active"><i class="fas fa-users me-2"></i> Data Pendaftar</a></li>
                    <?php if ($_SESSION['admin_level'] == 'super_admin'): ?>
                        <li><a href="admin_tambah.php"><i class="fas fa-user-plus me-2"></i> Tambah Admin</a></li>
                    <?php endif; ?>
                    <li><a href="admin_pengaturan.php"><i class="fas fa-cog me-2"></i> Pengaturan</a></li>
                    <li><a href="admin_logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <?php if(isset($notif_success)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-envelope me-2"></i> <?= $notif_success ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-users me-2"></i> Data Pendaftar</h5>
                    <div>
                        <a href="export_excel.php" class="btn btn-success btn-sm me-2">
                            <i class="fas fa-file-excel me-1"></i> Export ke Excel
                        </a>
                        <a href="admin_pendaftar.php" class="btn btn-light btn-sm">Semua</a>
                        <a href="admin_pendaftar.php?status=pending" class="btn btn-warning btn-sm">Pending</a>
                        <a href="admin_pendaftar.php?status=verifikasi" class="btn btn-info btn-sm">Verifikasi</a>
                        <a href="admin_pendaftar.php?status=diterima" class="btn btn-success btn-sm">Diterima</a>
                        <a href="admin_pendaftar.php?status=ditolak" class="btn btn-danger btn-sm">Ditolak</a>
                    </div>
                </div>
                <div class="card-body p-0">
                    <table class="table table-bordered mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>No Pendaftaran</th>
                                <th>Nama</th>
                                <th>Tgl Daftar</th>
                                <th>Status</th>
                                <th>Aksi</th>
                                <th>Notifikasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = $offset + 1; foreach($pendaftar as $p): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $p['no_pendaftaran'] ?></td>
                                <td><?= htmlspecialchars($p['nama_lengkap']) ?></td>
                                <td><?= date('d-m-Y', strtotime($p['tanggal_daftar'])) ?></td>
                                <td>
                                    <?php
                                    $badge = 'secondary';
                                    if($p['status'] == 'pending') $badge = 'warning';
                                    elseif($p['status'] == 'verifikasi') $badge = 'info';
                                    elseif($p['status'] == 'diterima') $badge = 'success';
                                    elseif($p['status'] == 'ditolak') $badge = 'danger';
                                    ?>
                                    <span class="badge bg-<?= $badge ?>"><?= strtoupper($p['status']) ?></span>
                                </td>
                                <td>
                                    <a href="admin_edit_pendaftar.php?id=<?= $p['id'] ?>" class="btn btn-primary btn-sm btn-sm-custom">Edit</a>
                                    <a href="admin_hapus.php?id=<?= $p['id'] ?>" class="btn btn-danger btn-sm btn-sm-custom" onclick="return confirm('Yakin hapus data ini?')">Hapus</a>
                                </td>
                                <td>
                                    <a href="?kirim_notif=1&id=<?= $p['id'] ?>" class="btn btn-notif btn-sm" onclick="return confirm('Kirim notifikasi status ke email pendaftar?')">
                                        <i class="fas fa-envelope me-1"></i> Kirim Notif
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(count($pendaftar) == 0): ?>
                            <td><td colspan="7" class="text-center">Belum ada data pendaftar</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php if($total_pages > 1): ?>
                <div class="card-footer">
                    <nav>
                        <ul class="pagination mb-0">
                            <?php for($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>&status=<?= $status_filter ?>"><?= $i ?></a>
                            </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>