<?php
require_once 'config/database.php';

$stmt = $pdo->query("SELECT * FROM pengaturan WHERE id = 1");
$setting = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PPDB - SMK N 1 LIWA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #e3f2fd 0%, #90caf9 50%, #ffffff 100%);
            min-height: 100vh;
        }
        
        /* Navbar */
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 15px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .navbar-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            color: #0d47a1 !important;
            font-weight: bold;
            font-size: 22px;
        }
        
        .navbar-brand img {
            height: 40px;
            width: auto;
        }
        
        .nav-link {
            color: #0d47a1 !important;
            font-weight: 500;
        }
        
        /* Hero Section */
        .hero {
            min-height: 80vh;
            display: flex;
            align-items: center;
            padding: 60px 0;
        }
        
        .hero h1 {
            font-size: 48px;
            font-weight: 800;
            color: #0d47a1;
            margin-bottom: 20px;
            line-height: 1.2;
        }
        
        .hero p {
            font-size: 18px;
            color: #37474f;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        /* Tombol */
        .btn-primary-custom {
            background: linear-gradient(135deg, #0d47a1 0%, #1976d2 100%);
            color: white;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            transition: 0.3s;
            border: none;
            margin-right: 15px;
        }
        
        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(13,71,161,0.4);
            color: white;
        }
        
        .btn-outline-custom {
            background: transparent;
            border: 2px solid #0d47a1;
            color: #0d47a1;
            padding: 12px 35px;
            border-radius: 50px;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            transition: 0.3s;
        }
        
        .btn-outline-custom:hover {
            background: #0d47a1;
            color: white;
            transform: translateY(-2px);
        }
        
        /* Info Link */
        .info-link {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid rgba(0,0,0,0.1);
        }
        
        .info-link p {
            color: #37474f;
            margin-bottom: 10px;
        }
        
        .info-link a {
            color: #0d47a1;
            text-decoration: none;
            font-weight: 500;
        }
        
        .info-link a:hover {
            text-decoration: underline;
        }
        
        .info-link small {
            background: #f0f2f5;
            padding: 5px 12px;
            border-radius: 20px;
            display: inline-block;
            margin-top: 5px;
        }
        
        /* Hero Image */
        .hero-image {
            text-align: center;
        }
        
        .hero-image img {
            max-width: 100%;
            border-radius: 20px;
        }
        
        /* Footer */
        .footer {
            text-align: center;
            padding: 20px;
            color: #37474f;
            font-size: 14px;
            background: rgba(255,255,255,0.8);
            border-radius: 20px 20px 0 0;
        }
        
        @media (max-width: 768px) {
            .hero h1 { font-size: 32px; }
            .hero p { font-size: 16px; }
            .btn-primary-custom, .btn-outline-custom { 
                padding: 10px 20px; 
                font-size: 14px;
                margin-bottom: 10px;
                margin-right: 10px;
            }
            .navbar-brand img {
                height: 35px;
            }
            .navbar-brand {
                font-size: 18px;
            }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img src="/PPDB/assets/img/logo.jpg" alt="Logo SMK N 1 LIWA">
            SMK N 1 LIWA
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon" style="background-color: #0d47a1; border-radius: 3px;"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="portal.php">Portal</a></li>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="login_choice.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="register.php">Daftar</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<div class="hero">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <h1>Raih Masa Depanmu di <br>SMK N 1 LIWA</h1>
                <p>
                    Bergabunglah dengan calon siswa lainnya yang telah mewujudkan impian mereka. 
                    Akses informasi lengkap dan lakukan pendaftaran untuk memasuki sekolah impianmu.
                </p>
                <div class="d-flex flex-wrap">
                    <a href="register.php" class="btn-primary-custom">
                        <i class="fas fa-user-plus me-2"></i> Mulai Pendaftaran
                    </a>
                    <a href="login_choice.php" class="btn-outline-custom">
                        <i class="fas fa-sign-in-alt me-2"></i> Sudah punya akun? Masuk
                    </a>
                </div>
                <div class="info-link">
                    <p>
                        <i class="fas fa-bell me-2"></i> Baca pengumuman terbaru dan informasi penting di 
                        <a href="portal.php">Portal PPDB</a>
                    </p>
                    <p class="mt-2">
                        <i class="fas fa-link me-2"></i> Untuk mengakses laman pendaftaran, kunjungi:
                    </p>
                    <small>
                        <i class="fas fa-globe me-1"></i> <?= $_SERVER['HTTP_HOST'] ?>/PPDB/register.php
                    </small>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="hero-image">
                    <img src="assets/img/karakter-siswa.png" alt="Karakter Siswa" onerror="this.style.display='none'">
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    <div class="container">
        <p>&copy; <?= date('Y') ?> SMK N 1 LIWA - Penerimaan Peserta Didik Baru</p>
        <small><?= nl2br(htmlspecialchars($setting['alamat_sekolah'] ?? 'Jl. Pendidikan No. 1, Liwa, Lampung Barat')) ?></small>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>