<?php
session_start();
require_once 'config/database.php';

// Cek login admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$success = '';
$error = '';

// Ambil data pengaturan
$stmt = $pdo->query("SELECT * FROM pengaturan WHERE id = 1");
$setting = $stmt->fetch();

// Jika belum ada data pengaturan, buat default
if (!$setting) {
    $pdo->exec("INSERT INTO pengaturan (id, nama_sekolah, alamat_sekolah, no_telepon, email_sekolah, tahun_ajaran, kuota_pendaftar, status_pendaftaran) 
                VALUES (1, 'SMK N 1 LIWA', 'Jl. Pendidikan No. 1, Liwa, Lampung Barat', '(0728) 12345', 'info@smkn1liwa.sch.id', '2025/2026', 100, 'buka')");
    $stmt = $pdo->query("SELECT * FROM pengaturan WHERE id = 1");
    $setting = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_sekolah = trim($_POST['nama_sekolah']);
    $alamat_sekolah = trim($_POST['alamat_sekolah']);
    $no_telepon = trim($_POST['no_telepon']);
    $email_sekolah = trim($_POST['email_sekolah']);
    $tahun_ajaran = trim($_POST['tahun_ajaran']);
    $kuota_pendaftar = (int)$_POST['kuota_pendaftar'];
    $status_pendaftaran = $_POST['status_pendaftaran'];

    if (empty($nama_sekolah) || empty($alamat_sekolah)) {
        $error = "Nama sekolah dan alamat wajib diisi!";
    } else {
        $stmt = $pdo->prepare("UPDATE pengaturan SET 
            nama_sekolah = ?,
            alamat_sekolah = ?,
            no_telepon = ?,
            email_sekolah = ?,
            tahun_ajaran = ?,
            kuota_pendaftar = ?,
            status_pendaftaran = ?
            WHERE id = 1");
        
        if ($stmt->execute([$nama_sekolah, $alamat_sekolah, $no_telepon, $email_sekolah, $tahun_ajaran, $kuota_pendaftar, $status_pendaftaran])) {
            $success = "Pengaturan berhasil disimpan!";
            // Refresh data
            $stmt = $pdo->query("SELECT * FROM pengaturan WHERE id = 1");
            $setting = $stmt->fetch();
        } else {
            $error = "Gagal menyimpan pengaturan!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaturan - Admin PPDB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        .sidebar { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .sidebar a { text-decoration: none; color: #333; display: block; padding: 10px; border-radius: 8px; margin-bottom: 5px; }
        .sidebar a:hover, .sidebar a.active { background: #0d47a1; color: white; }
        .navbar { background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.05); padding: 12px 0; }
        .card-custom { background: white; border-radius: 15px; padding: 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .btn-simpan { background: linear-gradient(135deg, #0d47a1, #1976d2); color: white; padding: 10px 30px; border-radius: 50px; border: none; }
        .btn-simpan:hover { transform: translateY(-2px); }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary" href="admin_dashboard.php">
            <i class="fas fa-school"></i> Admin PPDB
        </a>
        <div>
            <span class="text-muted me-3">Halo, <?= htmlspecialchars($_SESSION['admin_nama']) ?></span>
            <a href="admin_logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="sidebar">
                <h5 class="mb-3">Menu Admin</h5>
                <ul class="list-unstyled">
                    <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
                    <li><a href="admin_pendaftar.php"><i class="fas fa-users me-2"></i> Data Pendaftar</a></li>
                    <li><a href="admin_tambah.php"><i class="fas fa-user-plus me-2"></i> Tambah Admin</a></li>
                    <li><a href="admin_pengaturan.php" class="active"><i class="fas fa-cog me-2"></i> Pengaturan</a></li>
                    <li><a href="admin_logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                </ul>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <div class="card-custom">
                <h4 class="mb-4" style="color: #0d47a1;"><i class="fas fa-cog me-2"></i> Pengaturan Sekolah</h4>
                
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i> <?= $success ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i> <?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Nama Sekolah</label>
                            <input type="text" name="nama_sekolah" class="form-control" value="<?= htmlspecialchars($setting['nama_sekolah']) ?>" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Alamat Sekolah</label>
                            <textarea name="alamat_sekolah" class="form-control" rows="3" required><?= htmlspecialchars($setting['alamat_sekolah']) ?></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">No Telepon</label>
                            <input type="text" name="no_telepon" class="form-control" value="<?= htmlspecialchars($setting['no_telepon']) ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email Sekolah</label>
                            <input type="email" name="email_sekolah" class="form-control" value="<?= htmlspecialchars($setting['email_sekolah']) ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tahun Ajaran</label>
                            <input type="text" name="tahun_ajaran" class="form-control" value="<?= htmlspecialchars($setting['tahun_ajaran']) ?>" placeholder="2025/2026">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Kuota Pendaftar</label>
                            <input type="number" name="kuota_pendaftar" class="form-control" value="<?= $setting['kuota_pendaftar'] ?>">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Status Pendaftaran</label>
                            <select name="status_pendaftaran" class="form-control">
                                <option value="buka" <?= $setting['status_pendaftaran'] == 'buka' ? 'selected' : '' ?>>Buka (Pendaftaran Dibuka)</option>
                                <option value="tutup" <?= $setting['status_pendaftaran'] == 'tutup' ? 'selected' : '' ?>>Tutup (Pendaftaran Ditutup)</option>
                            </select>
                        </div>
                    </div>
                    <div class="text-center mt-3">
                        <button type="submit" class="btn-simpan"><i class="fas fa-save me-2"></i> Simpan Pengaturan</button>
                        <a href="admin_dashboard.php" class="btn btn-secondary ms-2">Kembali</a>
                    </div>
                </form>
            </div>
            
            <!-- Informasi Tambahan -->
            <div class="card-custom mt-4">
                <h5 class="mb-3" style="color: #0d47a1;"><i class="fas fa-info-circle me-2"></i> Informasi Sistem</h5>
                <table class="table table-bordered">
                    <tr><th width="200">Versi Aplikasi</th><td>PPDB Online v2.0</td></tr>
                    <tr><th>Total Pendaftar</th><td><?= $pdo->query("SELECT COUNT(*) FROM pendaftar")->fetchColumn() ?> orang</td></tr>
                    <tr><th>Total Admin</th><td><?= $pdo->query("SELECT COUNT(*) FROM admin")->fetchColumn() ?> orang</td></tr>
                    <tr><th>Tanggal Server</th><td><?= date('d-m-Y H:i:s') ?></td></tr>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>