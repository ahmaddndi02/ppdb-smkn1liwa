<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("DELETE FROM pendaftar WHERE id = ?");
$stmt->execute([$id]);

header("Location: admin_pendaftar.php");
exit;
?>