<?php
session_start();
require_once 'config/database.php';

if (isset($_SESSION['user_id'])) {
    header("Location: portal.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = "Email dan password wajib diisi!";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_nama'] = $user['nama_lengkap'];
            header("Location: portal.php");
            exit;
        } else {
            $error = "Email atau password salah!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Siswa - SMK N 1 LIWA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #e3f2fd, #ffffff);
            font-family: 'Segoe UI', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .login-card {
            background: white;
            border-radius: 20px;
            padding: 35px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            max-width: 450px;
            margin: auto;
        }
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo img {
            height: 70px;
            width: auto;
            margin-bottom: 10px;
        }
        .logo h3 {
            color: #0d47a1;
            margin: 0;
            font-weight: bold;
        }
        .logo p {
            color: #6c757d;
            margin-top: 5px;
        }
        .btn-login {
            background: linear-gradient(135deg, #0d47a1, #1976d2);
            color: white;
            padding: 12px;
            border-radius: 50px;
            font-weight: bold;
            border: none;
            width: 100%;
            transition: 0.3s;
        }
        .btn-login:hover {
            transform: translateY(-2px);
        }
        .forgot-password {
            text-align: center;
            margin-top: 10px;
        }
        .forgot-password a {
            color: #6c757d;
            text-decoration: none;
            font-size: 14px;
        }
        .forgot-password a:hover {
            color: #0d47a1;
            text-decoration: underline;
        }
        .back-link {
            text-align: center;
            margin-top: 15px;
        }
        .back-link a {
            color: #6c757d;
            text-decoration: none;
        }
        .back-link a:hover {
            color: #0d47a1;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="login-card">
        <div class="logo">
            <img src="assets/img/logo.jpg" alt="Logo SMK N 1 LIWA">
            <h3>Login Siswa</h3>
            <p>SMK N 1 LIWA</p>
        </div>
        
        <?php if($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i> <?= $error ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" placeholder="Masukkan email" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
            </div>
            <button type="submit" class="btn-login">
                <i class="fas fa-sign-in-alt me-2"></i> Login sebagai Siswa
            </button>
        </form>
        
        <!-- LINK LUPA PASSWORD -->
        <div class="forgot-password">
            <a href="lupa_password.php"><i class="fas fa-key me-1"></i> Lupa password?</a>
        </div>
        
        <div class="back-link">
            <a href="login_choice.php">
                <i class="fas fa-arrow-left me-1"></i> Kembali ke Pilihan Login
            </a>
        </div>
        <hr>
        <p class="text-center mb-0">Belum punya akun? <a href="register.php">Daftar sekarang</a></p>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>